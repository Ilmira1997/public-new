<?php
require_once('header.php');
require_once('students/variables.php');

$myCurl = curl_init();

$url = $API_ADDRESS . '/v2/webinars/v2/template_messages';

curl_setopt_array($myCurl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => false
));
$webinars_template_messages = curl_exec($myCurl);
curl_close($myCurl);
$webinars_template_messages = json_decode($webinars_template_messages);
$webinars_template_messages = $webinars_template_messages->data;

$url = 'https://v1-ts.tehnikum.uz/tehnikum_students/api/get_table_data';
$data = array(
    "token" => "g7G^a9as(qj3wL{FZ#D>$",
    "columnName" => "lesson_type",
);
$postdata = json_encode($data);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
$lesson_types = json_decode($result);

$url = 'https://v1-ts.tehnikum.uz/tehnikum_students/api/get_table_data';
$data = array(
    "token" => "g7G^a9as(qj3wL{FZ#D>$",
    "columnName" => "webinar_language",
);
$postdata = json_encode($data);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
$webinar_languages = json_decode($result);

$url = 'https://v1-ts.tehnikum.uz/tehnikum_students/api/get_table_data';
$data = array(
    "token" => "g7G^a9as(qj3wL{FZ#D>$",
    "columnName" => "webinar_pool",
);
$postdata = json_encode($data);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
$webinar_pools = json_decode($result);

$myCurlC = curl_init();
curl_setopt_array($myCurlC, array(
    CURLOPT_URL => 'https://v1-ts.tehnikum.uz/tehnikum_students/api/get_courses',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => false
));
$courses = curl_exec($myCurlC);
curl_close($myCurlC);
$courses = json_decode($courses);

$myCurl = curl_init();

$url = $API_ADDRESS . '/v2/webinars/v2/webinars?&is_question=true&is_messages=true&webinar_id='.$_GET['id'];

curl_setopt_array($myCurl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => false
));
$webinar_info = curl_exec($myCurl);
curl_close($myCurl);
$webinar_info = json_decode($webinar_info);
$webinar_info = $webinar_info->data[0];

?>
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <div class="row">
            <div id="api_address" data-value="<?php echo $API_ADDRESS ?>"></div>
            <div class="col-12">
                <div class="card py-3 px-md-3 shadow row">
                    <h2 class="card-title" style="padding: 1.25rem;padding-bottom:0">Изменить вебинар</h2>
                    <hr />
                    <div class="card-body info" >
                        <h4 class="card-title">Информация о вебинаре</h4>
                        <div>
                            <label class="mr-sm-2" for="title" style="margin-top: .5rem; margin-bottom: .25rem">Название вебинара</label>
                            <input type="text" name="title" id="title" placeholder="Название вебинара" value="<?php echo $webinar_info->title ?>" class="form-control">
                        </div>
                        <div>
                            <label class="mr-sm-2" for="language" style="margin-top: .5rem; margin-bottom: .25rem">Язык</label>
                            <select class="custom-select" id="language" name="language">
                                <?php foreach ($webinar_languages as $webinar_language) { ?>
                                    <option value="<?php echo $webinar_language->id ?>" <?php echo $webinar_language->id == $webinar_info->language_id ? 'selected' : '' ?>><?php echo $webinar_language->title ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <label class="mr-sm-2" for="date_start" style="margin-top: .5rem; margin-bottom: .25rem">Дата начала</label>
                            <input type="date" class="form-control" id="date_start" value="<?php echo explode("T", $webinar_info->date_time_start)[0] ?>" name="date_start">
                        </div>
                        <div>
                            <label class="mr-sm-2" for="time_start" style="margin-top: .5rem; margin-bottom: .25rem">Время начала</label>
                            <input type="time" class="form-control" id="time_start" value="<?php echo $webinar_info->date_start_time ?>" name="time_start">
                        </div>
                        <div>
                            <label class="mr-sm-2" for="time_start" style="margin-top: .5rem; margin-bottom: .25rem">Курс</label>
                            <select class="custom-select" id="courseSelect" name="course">
                                <?php foreach ($courses->data as $value) { ?>
                                    <?php foreach($value->threads as $thread) { ?>
                                        <option value="<?php echo $thread->id ?>" <?php echo $thread->id == $webinar_info->course_thread_id ? 'selected' : '' ?>><?php echo $value->name ?> - <?php echo $thread->thread ?>, <?php echo $value->direction?></option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <label class="mr-sm-2" for="lesson_type" style="margin-top: .5rem; margin-bottom: .25rem">Тип занятия</label>
                            <select class="custom-select" id="lesson_type" name="lesson_type">
                                <?php foreach ($lesson_types as $lesson_type) { ?>
                                    <option value="<?php echo $lesson_type->id ?>" <?php echo $lesson_type->id == $webinar_info->lesson_type_id ? 'selected' : '' ?>><?php echo $lesson_type->type ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <label class="mr-sm-2" for="theme" style="margin-top: .5rem; margin-bottom: .25rem">Тема БЛ</label>
                            <input type="text" name="theme" id="theme" placeholder="Тема БЛ" value="<?php echo $webinar_info->theme ?>" class="form-control">
                        </div>
                        <div>
                            <label class="mr-sm-2" for="speaker" style="margin-top: .5rem; margin-bottom: .25rem">Спикер</label>
                            <input type="text" name="speaker" id="speaker" placeholder="Спикер" value="<?php echo $webinar_info->speaker ?>" class="form-control">
                        </div>
                        <div>
                            <label class="mr-sm-2" for="register_plan" style="margin-top: .5rem; margin-bottom: .25rem">План регистраций</label>
                            <input type="number" name="register_plan" id="register_plan" placeholder="План регистраций" value="<?php echo $webinar_info->register_plan ?>" class="form-control">
                        </div>
                        <div>
                            <label class="mr-sm-2" for="budget_plan" style="margin-top: .5rem; margin-bottom: .25rem">План бюджета</label>
                            <input type="text" name="budget_plan" id="budget_plan" placeholder="План бюджета" value="<?php echo $webinar_info->budget_plan ?>" class="form-control">
                        </div>
                    </div>
                    <hr />
                    <div class="card-body info" >
                        <h4 class="card-title">Опрос</h4>
                        <div>
                            <label for="question" style="margin-top: .5rem; padding-left: 0;margin-bottom: 0" class="col-12">Вопрос</label>
                            <textarea class="form-control" rows="3" id="question" name="question" placeholder="Вопрос"><?php echo $webinar_info->question ?></textarea>
                        </div>
                        <div>
                            <label for="question" style="margin-top: .5rem; padding-left: 0;margin-bottom: 0" class="col-12">Варианты ответа</label>
                            <div class="col-md-11 mt-2">
                                <input name="answer_group" class="material-inputs" type="radio" id="radio_1" value="answer_one" <?php echo $webinar_info->right_answer == $webinar_info->answer_one ? 'checked' : '' ?> />
                                <label for="radio_1" class="col-12"> <textarea class="form-control" rows="3" name="answer_one" id="answer_one" placeholder="Первый вопрос"><?php echo $webinar_info->answer_one ?></textarea></label>
                            </div>
                            <div class="col-md-11 mt-5">
                                <input name="answer_group" class="material-inputs" type="radio" id="radio_2" value="answer_two" <?php echo $webinar_info->right_answer == $webinar_info->answer_two ? 'checked' : '' ?> />
                                <label for="radio_2" class="col-12"> <textarea class="form-control" rows="3" name="answer_two" id="answer_two" placeholder="Второй вопрос"><?php echo $webinar_info->answer_two ?></textarea></label>
                            </div>
                            <div class="col-md-11 mt-5">
                                <input name="answer_group" class="material-inputs" type="radio" id="radio_3" value="answer_three" <?php echo $webinar_info->right_answer == $webinar_info->answer_three ? 'checked' : '' ?> />
                                <label for="radio_3" class="col-12"> <textarea class="form-control" rows="3" name="answer_three" id="answer_three" placeholder="Третий вопрос"><?php echo $webinar_info->answer_three ?></textarea></label>
                            </div>
                            <div class="col-md-11 mt-5">
                                <input name="answer_group" class="material-inputs" type="radio" id="radio_4" value="answer_four" <?php echo $webinar_info->right_answer == $webinar_info->answer_four ? 'checked' : '' ?> />
                                <label for="radio_4" class="col-12"> <textarea class="form-control" rows="3" name="answer_four" id="answer_four" placeholder="Четвертый вопрос"><?php echo $webinar_info->answer_four ?></textarea></label>
                            </div>
                        </div>
                        <div>
                            <label for="right_answer_text" style="margin-top: 2rem; padding-left: 0;margin-bottom: 0" class="col-12">Текст для пользователя, который ответил правильно</label>
                            <textarea class="form-control" rows="3" id="right_answer_text" name="right_answer_text" placeholder="Текст для пользователя, который ответил правильно"><?php echo $webinar_info->right_answer_text ?></textarea>
                        </div>
                        <div>
                            <label for="wrong_answer_text" style="margin-top: .5rem; padding-left: 0;margin-bottom: 0" class="col-12">Текст для пользователя, который ответил неправильно</label>
                            <textarea class="form-control" rows="3" id="wrong_answer_text" name="wrong_answer_text" placeholder="Текст для пользователя, который ответил неправильно"><?php echo $webinar_info->wrong_answer_text ?></textarea>
                        </div>
                    </div>
                    <hr />
                    <div class="card-body info" >
                        <h4 class="card-title">Вебинарные пулы</h4>
                        <?php foreach ($webinar_pools as $webinar_pool) {

                            $is_checked = false;

                            foreach ($webinar_info->webinar_pools as $webinar_pool_info) {
                                if ($webinar_pool_info->webinar_pool_id == $webinar_pool->id) {
                                    $is_checked = true;
                                }
                            }

                            ?>
                            <div class="col-md-11 mt-3">
                                <input name="checkbox_webinar_pool_group"  class="material-inputs" <?php echo $is_checked ? 'checked' : ''?> type="checkbox" id="checkbox_webinar_pool_<?php echo $webinar_pool->id ?>" value="<?php echo $webinar_pool->id ?>" />
                                <label for="checkbox_webinar_pool_<?php echo $webinar_pool->id ?>" class="col-12"><?php echo $webinar_pool->title ?></label>
                            </div>
                        <?php } ?>
                    </div>
                    <hr />
                    <?php foreach ($webinars_template_messages as $webinars_template_message) { ?>
                        <div class="card-body messages">
                            <h4 class="card-title">Сцена <?php echo $webinars_template_message->scene ?></h4>

                            <?php foreach ($webinars_template_message->messages as $message) {
                                $text = '';

                                foreach ($webinar_info->webinar_messages as $webinar_message) {
                                    if ($webinar_message->webinar_scene_message_type_id == $message->id) {
                                        $text = $webinar_message->message;
                                    }
                                }

                                ?>
                                <div>
                                    <label for="<?php echo $message->name . $message->id ?>" style="margin-top: .5rem; padding-left: 0;margin-bottom: 0" class="col-12"><?php echo $message->message_type ?></label>
                                    <textarea class="form-control webinar_scene_message" data-id="<?php echo $message->id ?>" rows="3" id="<?php echo $message->name . $message->id ?>" name="<?php echo $message->name ?>" placeholder="<?php echo $message->message_type ?>"><?php echo $text ?></textarea>
                                    <small class="form-text text-muted"><?php echo $message->hint ?></small>
                                </div>
                            <?php } ?>
                        </div>
                    <?php } ?>
                    <button class="btn btn-success mt-3 mt-md-0 py-3 col-md-3 h-100 btn_add" type="button">Сохранить
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <footer class="footer">
        © 2020 Material Pro Admin by wrappixel.com
    </footer>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- customizer Panel -->
<!-- ============================================================== -->

<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/extra-libs/taskboard/js/jquery.ui.touch-punch-improved.js"></script>
<script src="../assets/extra-libs/taskboard/js/jquery-ui.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- apps -->
<script src="../dist/js/app.min.js"></script>
<script src="../dist/js/app.init.js"></script>
<script src="../dist/js/app-style-switcher.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="../assets/extra-libs/sparkline/sparkline.js"></script>
<!--Wave Effects -->
<script src="../dist/js/waves.js"></script>
<!--Menu sidebar -->
<script src="../dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="../dist/js/custom.min.js"></script>
<script src="../dist/js/moment.min.js"></script>
<script src="../dist/js/moment_ru.js"></script>
<!--This page JavaScript -->
<script src="../assets/extra-libs/taskboard/js/lobilist.js"></script>
<script src="../assets/extra-libs/taskboard/js/lobibox.min.js"></script>
<script src="../assets/extra-libs/taskboard/js/task-init.js"></script>
<script src="../dist/js/sweetalert2.all.min.js"></script>
<script src="../dist/js/select2.full.min.js"></script>

<script type="text/javascript">
    const TOKEN = 'g7G^a9as(qj3wL{FZ#D>$'
    const API_ADDRESS = $('#api_address').data('value')
    const API_TOKEN_FOR_ADMIN='35e3f9151a3044c38c3eba716d4b12a9'
    const USERS_TO_DELETE_WEBINAR = [1918321]
    const regexFloat = /[+-]?\d+(\.\d+)?/g;

    function numberWithSpaces(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    }

    function getFloat(str) {
        if (str) {
            return parseFloat(str.match(regexFloat).join(''));
        }
        return 0.0
    }

    function matchCustom(params, data) {
        // If there are no search terms, return all of the data
        if ($.trim(params.term) === '') {
            return data;
        }

        // Do not display the item if there is no 'text' property
        if (typeof data.text === 'undefined') {
            return null;
        }

        // `params.term` should be the term that is used for searching
        // `data.text` is the text that is displayed for the data object
        if (data.text.indexOf(params.term) > -1) {
            var modifiedData = $.extend({}, data, true);
            modifiedData.text += '';

            // You can return modified objects from here
            // This includes matching the `children` how you want in nested data sets
            return modifiedData;
        }

        // Return `null` if the term should not be displayed
        return null;
    }

    function parse_query_string(query) {
        var vars = query.split("&");
        var query_string = {};
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            var key = decodeURIComponent(pair[0]);
            var value = decodeURIComponent(pair[1]);
            // If first entry with this name
            if (typeof query_string[key] === "undefined") {
                query_string[key] = decodeURIComponent(value);
                // If second entry with this name
            } else if (typeof query_string[key] === "string") {
                var arr = [query_string[key], decodeURIComponent(value)];
                query_string[key] = arr;
                // If third or later entry with this name
            } else {
                query_string[key].push(decodeURIComponent(value));
            }
        }
        return query_string;
    }

    $('input[name="budget_plan"]').on('input', function() {
        $(this).val(numberWithSpaces(($(this).val().replace(/ /g, ''))))
    })

    $("#courseSelect").select2({
        matcher: matchCustom,
        theme: "bootstrap"
    });

    $('.btn_add').click( async function(e) {
        e.preventDefault();
        e.target.disabled = true
        let query = window.location.search.substring(1);
        let qs = parse_query_string(query);

        let webinar_pool_ids = new Set()

        for (let webinar_pool of $('input[name="checkbox_webinar_pool_group"]:checked')) {
            webinar_pool_ids.add($(webinar_pool).val())
        }

        webinar_pool_ids = Array.from(webinar_pool_ids)

        const webinar_scene_messages = []

        for (let webinar_scene_message of $('.webinar_scene_message')) {
            webinar_scene_messages.push({
                id: $(webinar_scene_message).data('id'),
                message: $(webinar_scene_message).val()
            })
        }

        const data = {
            title: $('#title').val(),
            language_id: $('#language').val(),
            date_time_start: `${$('#date_start').val()} ${$('#time_start').val()}`,
            course_thread_id: $('#courseSelect').val(),
            lesson_type_id: $('#lesson_type').val(),
            theme: $('#theme').val(),
            speaker: $('#speaker').val(),
            register_plan: $('#register_plan').val(),
            budget_plan: getFloat($('#budget_plan').val()),
            question: {
                question: $('#question').val(),
                answer_one: $('#answer_one').val(),
                answer_two: $('#answer_two').val(),
                answer_three: $('#answer_three').val(),
                answer_four: $('#answer_four').val(),
                right_answer: $(`#${$("input[type='radio'][name='answer_group']:checked").val()}`).val(),
                right_answer_text: $('#right_answer_text').val(),
                wrong_answer_text: $('#wrong_answer_text').val()
            },
            webinar_pool_ids,
            webinar_scene_messages,
            clone_webinar_id: qs['id']
        }

        let res = await fetch(`${API_ADDRESS}/v2/webinars/v2/webinar`, {
            method: 'POST',
            headers: {
                'x-auth-token': API_TOKEN_FOR_ADMIN,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })

        res = await res.json()

        const url = new URL('https://tg-api.tehnikum.school/amo_crm/v1/create_lead')

        const params = {
            webinar_id: res['data'],
            action: 'bl-reg',
            webinarpool_webinarname: $('#title').val()
        }

        url.search = new URLSearchParams(params).toString()
        fetch(url)

        console.log('res', res)

        if (res['data']) {
            Swal.fire('Успех!', 'Вебинар добавился', 'success')
        } else {
            Swal.fire('Ошибка!', 'Случилась ошибка! Убедитесь, что вы заполнили все в "Информация о вебинаре"', 'error')
        }

        e.target.disabled = false
    })
</script>
<!-- Code injected by live-server -->
<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>

</html>