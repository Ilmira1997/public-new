

let now = new Date () //текущая дата
let finish = date = new Date(2024, 2, 1, 40, 0, 0)
let delta = Math.trunc( (finish - now)/1000 )

function convertSecondsToDHMS(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds %  (3600 * 24)) /3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = Math.floor(seconds / (3600 * 24));
    return {days, hours, minutes, seconds: remainingSeconds };
}

//Пример использования
const { days, hours, minutes, seconds } = convertSecondsToDHMS (delta) ;

let timerElems = document.querySelectorAll('.timerElem .num')
timerElems[0].innerHTML = twoDigitalsNum(days)
timerElems[1].innerHTML = twoDigitalsNum(hours)
timerElems[2].innerHTML = twoDigitalsNum(minutes)
console.log(timerElems)

function twoDigitalsNum(a) {
    if(a<10) {
        return `0${a}`
    } else {
        return a
    }
}

//PopUp start//

let whiteBtn = document.getElementsByClassName("white")[0];
let popUpWrapper =document.querySelector(".popUpForm")
let closeBtn= document.querySelector(".close");

whiteBtn.addEventListener("click",popUpForm);
closeBtn.addEventListener("click", closePopUp);

function popUpForm(){
    popUpWrapper.style.display="flex";
}

function closePopUp(){
    popUpWrapper.style.display="none";
}